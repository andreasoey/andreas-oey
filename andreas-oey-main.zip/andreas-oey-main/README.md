✅ Foto diri (image)

✅ Minimal 2 paragraf deskripsi tentang diri

✅ Menggunakan tag heading h1-h6 dan elemen komentar

✅ Menggunakan tag text formatting seperti <b>, <i>, <u>, <mark>, dll.

✅ Minimal 3 link (internal atau eksternal)

✅ Minimal 3 gambar

✅ Minimal 2 tabel

✅ Minimal 2 list (ordered/unordered list)
